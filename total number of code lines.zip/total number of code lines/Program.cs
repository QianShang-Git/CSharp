﻿using SoleFileBrowser;
using System;
using System.IO;
using System.Linq;

namespace total_number_of_code_lines
{
    class Program
    {
        public static string path = "";
        static void Main(string[] args)
        {
            string[] abs = Program.OpenChooseFile();
            foreach (var item in abs)
            {
                path = item;
            }
            if (path == "" || path == null) return;
            Console.WriteLine(path);
            string extension = ".cs";
            if (args.Length > 0)
            {
                extension = args[0];
            }
            int totalLines = CountLinesInDirectory(path, extension, new string[] { });
            Console.WriteLine($"Total lines of code in project for {extension} files: {totalLines}");
            Console.ReadKey();
        }

        static int CountLinesInDirectory(string directoryPath, string fileExtension, string[] excludeKeywords)
        {
            int totalLines = 0;
            var files = Directory.GetFiles(directoryPath, "*.*", SearchOption.AllDirectories)
              .Where(file => file.EndsWith(fileExtension) && !excludeKeywords.Any(keyword => file.Contains(keyword)));
            foreach (var file in files)
            {
                totalLines += CountLinesInFile(file);
            }
            return totalLines;
        }

        static int CountLinesInFile(string filePath)
        {
            int lines = 0;
            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string? line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line != null)
                        {
                            lines++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading file {filePath}: {ex.Message}");
            }
            return lines;
        }

        public static string[] OpenChooseFile()
        {
            return StandaloneFileBrowser.OpenFolderPanel("选择文件夹", "", false);
        }
    }
}